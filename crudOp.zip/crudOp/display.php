<!DOCTYPE html>
<html>
   <head>
      <title>Dashboard</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" 
          href="https://stackpath.bootstrapcdn.com/bootstrap/3.0.0/css/bootstrap.min.css">
</head>
<form> 
<body>
   <center>
   <h2 style="color:red"> <u>Vehicle Details</u></h2>
<br>
   <br>
 <?php 
 //Creating the reading page   
 // Include config file
 require_once "config.php";

 // Attempt select query execution
 $sql = "SELECT * FROM vehicle";
 if($result = mysqli_query($conn, $sql)){
 if(mysqli_num_rows($result) > 0){
 echo '<table bgcolor="black" width="400">';
 echo '<tr bgcolor="red">';
 echo "<th width='100'>Vehicle</th>";
 echo "<th width='100'>Brand</th>";
 echo "<th width='100'>Fuel</th>";
 echo "</tr>";
 while($row = mysqli_fetch_array($result)){
 echo "<tr bgcolor='white' align='center'>";
 echo "<td bgcolor='pink'>" . $row['vehicle'] . "</td>";
 echo "<td>" . $row['brand'] . "</td>";
 echo "<td>" . $row['fuel'] . "</td>";
 echo"<td></td>";
 echo "</tr>";
 }
 echo "</table>";
 // Free result set
 mysqli_free_result($result);
 } else{
    echo '<div class="alert alert-danger"><em>No records were found.</em></div>';
 }
 } else{
 echo "Oops! Something went wrong. Please try again later.";
 }
 // Close connection
 mysqli_close($conn);
 ?>
 <br>
 <div>
   <a href="create.php" class="btn btn-success "><i class="fa fa-plus"></i> Add Details of Vehicle</a>
   </div>
   <br>
   <div>
   <a href="update.php" class="btn btn-success "><i class="fa fa-plus"></i> Update</a>
   </div>
   <br>
   <div>
   <a href="delete.php" class="btn btn-success "><i class="fa fa-plus"></i> Delete</a>
   </div>
   <br>
   </center>
</body>
</html>