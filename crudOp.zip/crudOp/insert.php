<!DOCTYPE html>
<html>
 
<head>
    <title>Insert page</title>
</head>
 
<body>
    <center>
        <?php

        $conn = mysqli_connect("localhost", "root", "", "vehicle");
         
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. ". mysqli_connect_error());
        }
         
        // Taking all 4 values from the form data(input)
        $vehicle=$_REQUEST['vehicle'];
        $brand =  $_REQUEST['brand'];
        $fuel = $_REQUEST['fuel'];
        // Performing insert query execution
        // table name is vehicle
        $sql = "INSERT INTO vehicle(vehicle,brand, fuel) VALUES ('$vehicle','$brand',
            '$fuel')";
         
        if(mysqli_query($conn, $sql)){
            echo "<h3>data stored in a database successfully."
                . " Please browse your localhost php my admin"
                . " to view the updated data</h3>";
                $last_id = $conn->insert_id;
            echo "New record created successfully. Last inserted ID is: " . $last_id;
 
            echo nl2br("\n$vehicle\n $brand\n ". "$fuel\n");
            header("location: display.php");
        } else{
            echo "ERROR: Hush! Sorry $sql. ". mysqli_error($conn);
        }
        // Close connection
        mysqli_close($conn);
        ?>
    </center>
</body>
 
</html>