<?php error_reporting(0); ?>
<?php
include 'config.php';
if(count($_POST)>0) {
    //updating the data
mysqli_query($conn," UPDATE vehicle set vehicle='" . $_POST['vehicle'] . "', brand='" . $_POST['brand'] . "', fuel='" . $_POST['fuel'] . "'  WHERE vehicle='" . $_POST['vehicle'] . "'");
$message = "<h5><em>Record Modified Successfully</em></h5>";
}
$result = mysqli_query($conn,"SELECT * FROM vehicle WHERE vehicle='" . $_GET['vehicle'] . "'");
$row= mysqli_fetch_array($result);
?>
<html>
<head>
<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
    <title>Vehicle Details Update</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>

</head>
<body>
    <center>
<form name="frmUser" method="post" action="">
<div><?php if(isset($message)) { echo $message; } ?>
</div>
<h3 style="color:green"><u>UPDATE vehicle DETAILS</u> </h3>
 <br>
vehicle: <br>
<input type="text" name="vehicle" class="txtField" value="<?php echo $row['vehicle']; ?>">
<br>
brand :<br>
<input type="text" name="brand" class="txtField" value="<?php echo $row['brandname']; ?>">
<br>
fuel :<br>
<input type="text" name="fuel" class="txtField" value="<?php echo $row['fuel']; ?>">
<br> <br>
<input class="btn btn-primary" type="submit" value="Submit">
<br> <br>
<div style="padding-bottom:5px;">
<p> To view vehicle details 
<a class="btn btn-primary" href="display.php" role="button">Vehicle Details</a>
</div>
</p>
</center>
</form>
</body>
</html>


