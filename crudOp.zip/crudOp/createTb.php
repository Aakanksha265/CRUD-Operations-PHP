<?php
//creating table in the database
include 'config.php';
//using student_id as primary key
$sql="CREATE TABLE vehicle (
    vehicle  VARCHAR(100) NOT NULL  , 
    brand  VARCHAR(100) NOT NULL,
    fuel  VARCHAR(255) NOT NULL
   )";
   if ($conn->query($sql) === TRUE) {
    echo "Table Vehicle created successfully";
    } else {
    echo "Error creating table: " . $conn->error;
    }
    $conn->close();
    ?>