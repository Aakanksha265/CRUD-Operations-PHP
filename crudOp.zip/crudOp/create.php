<!DOCTYPE html>
<html lang="en">
   <head>
      <title>Store Data</title>
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.2/assets/css/docs.css" rel="stylesheet">
    <title>Bootstrap Example</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js"></script>
   </head>
   <body>
        <center>
         <h1>Storing Form data in Database</h1>
         <form action="insert.php", method="post">  
            <p>
               <label for="vehicle"> Vehicle_Name:</label>
               <input type="text" name="vehicle" id="vehicle"  required>
            </p>
            <p>
               <label for="brand"> Brand:</label>
               <input type="text" name="brand" id="brand"  required>
            </p>
            <p>
               <label for="fuel">Fuel:</label>
               <input type="text" name="fuel" id="fuel"  required>
            </p>
            
            <input class="btn btn-primary"  type="submit" value="Submit">
         </form>
        </center>
   </body>
</html>